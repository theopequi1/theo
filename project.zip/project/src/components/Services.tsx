import { Monitor, Shield, Cloud, Server, Cpu, PenTool as Tool, Home, Building2, Recycle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const serviceCategories = [
  {
    icon: Home,
    title: "Services aux Particuliers",
    path: "/individual",
    description: "Support informatique professionnel pour les particuliers avec éligibilité à 50% de réduction d'impôts.",
    features: [
      "Réparation à domicile ou en boutique",
      "Installation logicielle & support technique",
      "Assistance informatique personnalisée",
      "Formation et accompagnement",
      "Éligible aux services à la personne (50% de réduction d'impôts)"
    ],
    highlight: "✨ 50% de Réduction d'Impôts"
  },
  {
    icon: Building2,
    title: "Solutions Entreprises",
    path: "/professional",
    description: "Services informatiques complets pour entreprises de toutes tailles.",
    features: [
      "Maintenance & services managés",
      "Cybersécurité & sécurité réseau",
      "Infrastructure serveur & cloud",
      "Support technique PME",
      "Contrats de maintenance annuels"
    ],
    highlight: "🔒 Contrats de Maintenance Annuels"
  },
  {
    icon: Recycle,
    title: "Matériel Reconditionné",
    path: "/store",
    description: "Équipement informatique reconditionné de haute qualité avec garantie.",
    features: [
      "Ordinateurs reconditionnés certifiés",
      "Périphériques & accessoires",
      "Équipement réseau",
      "Alimentations & composants",
      "Contrôle qualité & garantie performance"
    ],
    highlight: "♻️ Solutions Éco-responsables"
  }
];

export const Services = () => {
  return (
    <section id="services" className="relative py-20 bg-cyber-darker/80 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-neon mb-4 animate-glow">Nos Services</h2>
          <p className="text-neon-blue text-lg max-w-3xl mx-auto">
            Solutions informatiques professionnelles pour particuliers et entreprises à Toulouse
          </p>
          <div className="mt-4 text-gray-300">
            <p>📍 Situé à Toulouse – Services disponibles sur rendez-vous</p>
            <p className="mt-2">📞 Contact : 05 82 95 09 25 / 06 14 65 71 31</p>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {serviceCategories.map((category, index) => (
            <Link to={category.path} key={category.title}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                whileHover={{ scale: 1.02 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-cyber-black p-8 rounded-lg border border-neon/20 hover:border-neon/50 transition-all group relative overflow-hidden h-full"
              >
                <div className="absolute top-0 right-0 bg-neon/10 p-3 rounded-bl-lg">
                  <category.icon className="w-8 h-8 text-neon group-hover:animate-pulse-neon" />
                </div>
                
                <h3 className="text-2xl font-semibold text-neon-blue mb-4 mt-2">{category.title}</h3>
                <p className="text-gray-300 mb-6">{category.description}</p>
                
                <ul className="space-y-3 mb-6">
                  {category.features.map((feature) => (
                    <li key={feature} className="flex items-start text-gray-400">
                      <span className="w-1.5 h-1.5 bg-neon rounded-full mr-2 mt-2" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <div className="mt-auto">
                  <div className="text-neon text-sm font-medium py-2 px-4 bg-neon/10 rounded-lg">
                    {category.highlight}
                  </div>
                </div>
              </motion.div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};