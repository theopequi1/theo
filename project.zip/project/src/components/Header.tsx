import { useState, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { Menu, X, ShoppingCart } from 'lucide-react';
import { motion } from 'framer-motion';
import { UserMenu } from './Auth/UserMenu';
import { Cart } from './Cart';
import { useCartStore } from '../store/useCartStore';
import { useAuthStore } from '../store/useAuthStore';

const navItems = [
  { name: 'Professionnels', path: '/professional' },
  { name: 'Particuliers', path: '/individual' },
  { name: 'Boutique', path: '/store' },
  { name: 'Contact', path: '/contact' },
];

export const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const { items } = useCartStore();
  const { isAuthenticated } = useAuthStore();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-cyber-black/80 backdrop-blur-md border-b border-neon/20' : 'bg-cyber-black/50 backdrop-blur-sm'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <NavLink
            to="/"
            className="text-2xl font-bold text-neon animate-glow"
          >
            IGUANE INFORMATIQUE
          </NavLink>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <NavLink
                key={item.name}
                to={item.path}
                className={({ isActive }) =>
                  `text-neon-blue hover:text-neon transition-colors ${
                    isActive ? 'text-neon font-semibold' : ''
                  }`
                }
              >
                {item.name}
              </NavLink>
            ))}
            {isAuthenticated && (
              <button
                onClick={() => setIsCartOpen(true)}
                className="relative text-neon-blue hover:text-neon transition-colors"
              >
                <ShoppingCart className="w-6 h-6" />
                {items.length > 0 && (
                  <span className="absolute -top-2 -right-2 bg-neon text-cyber-black w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold">
                    {items.length}
                  </span>
                )}
              </button>
            )}
            <UserMenu onProfileClick={() => navigate('/client/dashboard')} />
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-neon"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden py-4"
          >
            {navItems.map((item) => (
              <NavLink
                key={item.name}
                to={item.path}
                className={({ isActive }) =>
                  `block py-2 text-neon-blue hover:text-neon transition-colors ${
                    isActive ? 'text-neon font-semibold' : ''
                  }`
                }
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {item.name}
              </NavLink>
            ))}
            {isAuthenticated && (
              <button
                onClick={() => {
                  setIsCartOpen(true);
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center py-2 text-neon-blue hover:text-neon transition-colors"
              >
                <ShoppingCart className="w-6 h-6 mr-2" />
                Panier
                {items.length > 0 && (
                  <span className="ml-2 bg-neon text-cyber-black w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold">
                    {items.length}
                  </span>
                )}
              </button>
            )}
            <div className="py-2">
              <UserMenu onProfileClick={() => {
                navigate('/client/dashboard');
                setIsMobileMenuOpen(false);
              }} />
            </div>
          </motion.div>
        )}
      </div>

      <Cart isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </header>
  );
};