import { motion } from 'framer-motion';

const services = [
  {
    name: 'Sauvegarde de Données',
    priceHT: '40.83',
    priceTTC: '49',
    features: [
      'Sauvegarde complète du système',
      'Vérification des données',
      'Stockage sécurisé',
      'Test de récupération'
    ]
  },
  {
    name: 'Installation OS',
    priceHT: '57.50',
    priceTTC: '69',
    features: [
      'Installation propre',
      'Mise à jour des pilotes',
      'Configuration logicielle de base',
      'Optimisation système'
    ]
  },
  {
    name: 'Support sur Site',
    priceHT: '74.17',
    priceTTC: '89',
    features: [
      'Déplacement domicile/bureau',
      'Diagnostic matériel',
      'Configuration réseau',
      'Assistance immédiate'
    ]
  },
  {
    name: 'Maintenance Système',
    priceHT: '49.17',
    priceTTC: '59',
    features: [
      'Optimisation performances',
      'Suppression malwares',
      'Mises à jour logicielles',
      'Contrôle santé'
    ]
  }
];

export const ServicePricing = () => {
  return (
    <section className="py-20 bg-cyber-darker/80 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-neon mb-4 animate-glow">Tarifs des Services</h2>
          <p className="text-neon-blue text-lg">
            Prix transparents pour nos services les plus demandés
          </p>
          <p className="text-gray-300 mt-2">
            ✨ 50% de réduction d'impôts pour les services aux particuliers
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-cyber-black p-6 rounded-lg border border-neon/20 hover:border-neon/50 transition-all group"
            >
              <div className="text-center mb-6">
                <h3 className="text-xl font-semibold text-neon-blue mb-2">{service.name}</h3>
                <div className="space-y-1">
                  <div className="text-3xl font-bold text-neon">
                    {service.priceTTC}€
                    <span className="text-sm text-gray-400 ml-1">TTC</span>
                  </div>
                  <div className="text-lg text-gray-400">
                    {service.priceHT}€
                    <span className="text-sm ml-1">HT</span>
                  </div>
                </div>
              </div>

              <ul className="space-y-3">
                {service.features.map((feature) => (
                  <li key={feature} className="flex items-center text-gray-300">
                    <span className="w-1.5 h-1.5 bg-neon rounded-full mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};