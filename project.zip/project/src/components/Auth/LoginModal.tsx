import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Mail, Lock, User, Phone } from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface RegisterFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
  confirmPassword: string;
}

export const LoginModal = ({ isOpen, onClose }: LoginModalProps) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const login = useAuthStore((state) => state.login);

  // État pour le formulaire de connexion
  const [loginData, setLoginData] = useState({
    email: '',
    password: '',
  });

  // État pour le formulaire d'inscription
  const [registerData, setRegisterData] = useState<RegisterFormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
  });

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loginData.email && loginData.password) {
      // Simulation de connexion - À remplacer par votre logique d'authentification
      login({
        id: '1',
        email: loginData.email,
        firstName: 'John',
        lastName: 'Doe',
        phone: '',
        role: 'client',
      });
      onClose();
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (registerData.password !== registerData.confirmPassword) {
      alert('Les mots de passe ne correspondent pas');
      return;
    }
    // Simulation d'inscription - À remplacer par votre logique d'authentification
    login({
      id: '1',
      email: registerData.email,
      firstName: registerData.firstName,
      lastName: registerData.lastName,
      phone: registerData.phone,
      role: 'client',
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm"
          onClick={onClose}
        />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-cyber-black border border-neon/20 rounded-lg w-full max-w-md mx-4 relative z-50 max-h-[90vh] overflow-y-auto"
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-neon hover:text-neon-blue transition-colors"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="p-6">
            <h2 className="text-2xl font-bold text-neon mb-6">
              {isRegistering ? 'Créer un compte' : 'Connexion'}
            </h2>

            {isRegistering ? (
              <form onSubmit={handleRegisterSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="firstName" className="block text-gray-300 mb-2">
                      Prénom
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        id="firstName"
                        value={registerData.firstName}
                        onChange={(e) => setRegisterData({...registerData, firstName: e.target.value})}
                        className="w-full bg-cyber-darker border border-neon/20 rounded pl-10 p-3 text-gray-300 focus:border-neon focus:outline-none"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="lastName" className="block text-gray-300 mb-2">
                      Nom
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        id="lastName"
                        value={registerData.lastName}
                        onChange={(e) => setRegisterData({...registerData, lastName: e.target.value})}
                        className="w-full bg-cyber-darker border border-neon/20 rounded pl-10 p-3 text-gray-300 focus:border-neon focus:outline-none"
                        required
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label htmlFor="registerEmail" className="block text-gray-300 mb-2">
                    Email
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="email"
                      id="registerEmail"
                      value={registerData.email}
                      onChange={(e) => setRegisterData({...registerData, email: e.target.value})}
                      className="w-full bg-cyber-darker border border-neon/20 rounded pl-10 p-3 text-gray-300 focus:border-neon focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="phone" className="block text-gray-300 mb-2">
                    Téléphone
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="tel"
                      id="phone"
                      value={registerData.phone}
                      onChange={(e) => setRegisterData({...registerData, phone: e.target.value})}
                      className="w-full bg-cyber-darker border border-neon/20 rounded pl-10 p-3 text-gray-300 focus:border-neon focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="registerPassword" className="block text-gray-300 mb-2">
                    Mot de passe
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="password"
                      id="registerPassword"
                      value={registerData.password}
                      onChange={(e) => setRegisterData({...registerData, password: e.target.value})}
                      className="w-full bg-cyber-darker border border-neon/20 rounded pl-10 p-3 text-gray-300 focus:border-neon focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="confirmPassword" className="block text-gray-300 mb-2">
                    Confirmer le mot de passe
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="password"
                      id="confirmPassword"
                      value={registerData.confirmPassword}
                      onChange={(e) => setRegisterData({...registerData, confirmPassword: e.target.value})}
                      className="w-full bg-cyber-darker border border-neon/20 rounded pl-10 p-3 text-gray-300 focus:border-neon focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-neon text-cyber-black font-semibold py-3 rounded hover:shadow-neon transition-all"
                >
                  Créer un compte
                </button>
              </form>
            ) : (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label htmlFor="loginEmail" className="block text-gray-300 mb-2">
                    Email
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="email"
                      id="loginEmail"
                      value={loginData.email}
                      onChange={(e) => setLoginData({...loginData, email: e.target.value})}
                      className="w-full bg-cyber-darker border border-neon/20 rounded pl-10 p-3 text-gray-300 focus:border-neon focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="loginPassword" className="block text-gray-300 mb-2">
                    Mot de passe
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="password"
                      id="loginPassword"
                      value={loginData.password}
                      onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                      className="w-full bg-cyber-darker border border-neon/20 rounded pl-10 p-3 text-gray-300 focus:border-neon focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-neon text-cyber-black font-semibold py-3 rounded hover:shadow-neon transition-all"
                >
                  Se connecter
                </button>
              </form>
            )}

            <div className="mt-4 text-center">
              <button
                onClick={() => setIsRegistering(!isRegistering)}
                className="text-neon-blue hover:text-neon transition-colors"
              >
                {isRegistering
                  ? 'Déjà un compte ? Se connecter'
                  : 'Pas de compte ? S\'inscrire'}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};