import { useState } from 'react';
import { User, LogOut, Settings, ShoppingCart } from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';
import { LoginModal } from './LoginModal';
import { useNavigate } from 'react-router-dom';

interface UserMenuProps {
  onProfileClick?: () => void;
}

export const UserMenu = ({ onProfileClick }: UserMenuProps) => {
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuthStore();
  const navigate = useNavigate();

  return (
    <div className="relative">
      {isAuthenticated ? (
        <>
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="flex items-center space-x-2 text-neon-blue hover:text-neon transition-colors"
          >
            <User className="w-5 h-5" />
            <span>{user?.firstName} {user?.lastName}</span>
          </button>

          {isMenuOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-cyber-black border border-neon/20 rounded-lg shadow-lg py-1">
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  onProfileClick?.();
                }}
                className="flex items-center px-4 py-2 text-gray-300 hover:bg-neon/10 hover:text-neon w-full"
              >
                <Settings className="w-4 h-4 mr-2" />
                Mon Profil
              </button>
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  navigate('/client/orders');
                }}
                className="flex items-center px-4 py-2 text-gray-300 hover:bg-neon/10 hover:text-neon w-full"
              >
                <ShoppingCart className="w-4 h-4 mr-2" />
                Mes Commandes
              </button>
              <button
                onClick={() => {
                  logout();
                  setIsMenuOpen(false);
                }}
                className="flex items-center px-4 py-2 text-gray-300 hover:bg-neon/10 hover:text-neon w-full"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Déconnexion
              </button>
            </div>
          )}
        </>
      ) : (
        <button
          onClick={() => setIsLoginModalOpen(true)}
          className="flex items-center space-x-2 text-neon-blue hover:text-neon transition-colors"
        >
          <User className="w-5 h-5" />
          <span>Connexion</span>
        </button>
      )}

      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
      />
    </div>
  );
};