import { motion, AnimatePresence } from 'framer-motion';
import { X, ShoppingCart, Trash2, Plus, Minus } from 'lucide-react';
import { useCartStore } from '../store/useCartStore';
import { initiatePayment } from '../services/stripe';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
}

export const Cart = ({ isOpen, onClose }: CartProps) => {
  const { items, removeItem, updateQuantity, total, clearCart } = useCartStore();

  const handleCheckout = async () => {
    try {
      await initiatePayment(total(), 'Achat de matériel reconditionné');
    } catch (error) {
      console.error('Erreur lors du paiement:', error);
      alert('Une erreur est survenue lors du paiement. Veuillez réessayer.');
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm"
          onClick={onClose}
        />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-cyber-black border border-neon/20 rounded-lg w-full max-w-2xl mx-4 relative z-50 max-h-[90vh] overflow-y-auto"
        >
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center">
                <ShoppingCart className="w-6 h-6 text-neon mr-2" />
                <h2 className="text-2xl font-bold text-neon">Panier</h2>
              </div>
              <button
                onClick={onClose}
                className="text-neon hover:text-neon-blue transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {items.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-400">Votre panier est vide</p>
              </div>
            ) : (
              <>
                <div className="space-y-4">
                  {items.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between p-4 bg-cyber-darker rounded-lg"
                    >
                      <div className="flex items-center space-x-4">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-16 h-16 object-cover rounded"
                        />
                        <div>
                          <h3 className="text-neon-blue font-semibold">{item.name}</h3>
                          <p className="text-neon">{item.price}€</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => updateQuantity(item.id, Math.max(0, item.quantity - 1))}
                            className="p-1 text-neon hover:text-neon-blue transition-colors"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="text-gray-300 w-8 text-center">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="p-1 text-neon hover:text-neon-blue transition-colors"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                        <button
                          onClick={() => removeItem(item.id)}
                          className="text-red-500 hover:text-red-400 transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 pt-6 border-t border-neon/20">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-gray-400">Total</span>
                    <span className="text-2xl font-bold text-neon">{total()}€</span>
                  </div>
                  
                  <div className="flex space-x-4">
                    <button
                      onClick={clearCart}
                      className="flex-1 px-4 py-2 border border-red-500 text-red-500 rounded hover:bg-red-500/10 transition-colors"
                    >
                      Vider le panier
                    </button>
                    <button
                      onClick={handleCheckout}
                      className="flex-1 px-4 py-2 bg-neon text-cyber-black rounded font-semibold hover:shadow-neon transition-all"
                    >
                      Commander
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};