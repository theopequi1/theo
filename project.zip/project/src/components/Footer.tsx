import { NavLink } from 'react-router-dom';
import { Phone, Mail, MapPin } from 'lucide-react';

const navItems = [
  { name: 'Professionnels', path: '/professional' },
  { name: 'Particuliers', path: '/individual' },
  { name: 'Boutique', path: '/store' },
  { name: 'Contact', path: '/contact' },
];

export const Footer = () => {
  return (
    <footer className="bg-cyber-black border-t border-neon/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo et Info Entreprise */}
          <div className="space-y-4">
            <NavLink to="/" className="text-2xl font-bold text-neon animate-glow block">
              IGUANE INFORMATIQUE
            </NavLink>
            <p className="text-gray-400">
              Solutions Informatiques de Nouvelle Génération pour Professionnels et Particuliers
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="text-neon-blue font-semibold mb-4">Navigation</h3>
            <ul className="space-y-2">
              {navItems.map((item) => (
                <li key={item.name}>
                  <NavLink
                    to={item.path}
                    className="text-gray-400 hover:text-neon transition-colors"
                  >
                    {item.name}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-neon-blue font-semibold mb-4">Contact</h3>
            <ul className="space-y-2">
              <li className="flex items-center text-gray-400">
                <Phone className="w-4 h-4 mr-2 text-neon" />
                <span>05 82 95 09 25</span>
              </li>
              <li className="flex items-center text-gray-400">
                <Phone className="w-4 h-4 mr-2 text-neon" />
                <span>06 14 65 71 31</span>
              </li>
              <li className="flex items-center text-gray-400">
                <Mail className="w-4 h-4 mr-2 text-neon" />
                <span>contact@iguane-informatique.fr</span>
              </li>
              <li className="flex items-center text-gray-400">
                <MapPin className="w-4 h-4 mr-2 text-neon" />
                <span>Toulouse, France</span>
              </li>
            </ul>
          </div>

          {/* Horaires */}
          <div>
            <h3 className="text-neon-blue font-semibold mb-4">Horaires d'Ouverture</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Lundi - Vendredi : 9h00 - 18h00</li>
              <li>Samedi : Sur rendez-vous</li>
              <li>Dimanche : Fermé</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-neon/20">
          <p className="text-center text-gray-400">
            © {new Date().getFullYear()} IGUANE INFORMATIQUE. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
};