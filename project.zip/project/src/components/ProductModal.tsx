import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

interface ProductModalProps {
  product: {
    id: number;
    name: string;
    images: string[];
    description: string;
    specs: string[];
    priceHT: string;
    priceTTC: string;
    condition: string;
    eco: string;
    technicalDetails: string;
  };
  isOpen: boolean;
  onClose: () => void;
}

export const ProductModal = ({ product, isOpen, onClose }: ProductModalProps) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm"
          onClick={onClose}
        />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-cyber-black border border-neon/20 rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto relative z-50"
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-neon hover:text-neon-blue transition-colors"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="p-6">
            <h2 className="text-2xl font-bold text-neon mb-4">{product.name}</h2>
            
            {/* Image Gallery */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              {product.images.map((image, index) => (
                <img
                  key={index}
                  src={image}
                  alt={`${product.name} - Image ${index + 1}`}
                  className="rounded-lg w-full h-48 object-cover"
                />
              ))}
            </div>

            {/* Product Details */}
            <div className="space-y-6">
              <div>
                <h3 className="text-neon-blue font-semibold mb-2">Description</h3>
                <p className="text-gray-300">{product.description}</p>
              </div>

              <div>
                <h3 className="text-neon-blue font-semibold mb-2">Caractéristiques</h3>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {product.specs.map((spec, index) => (
                    <li key={index} className="flex items-center text-gray-300">
                      <span className="w-1.5 h-1.5 bg-neon rounded-full mr-2" />
                      {spec}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-neon">{product.priceTTC}€ TTC</div>
                  <div className="text-lg text-gray-400">{product.priceHT}€ HT</div>
                  <div className="text-sm text-green-400 bg-green-400/10 py-1 px-2 rounded mt-1">
                    {product.eco}
                  </div>
                </div>
                <a
                  href={`/technical-sheets/${product.technicalDetails}`}
                  download
                  className="px-4 py-2 bg-neon text-cyber-black rounded font-semibold hover:shadow-neon transition-all"
                >
                  Télécharger la Fiche Technique
                </a>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};