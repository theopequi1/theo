import { motion } from 'framer-motion';
import { useState } from 'react';
import { ProductModal } from './ProductModal';
import { CustomPCBuilder } from './CustomPCBuilder';
import { useCartStore } from '../store/useCartStore';
import { useAuthStore } from '../store/useAuthStore';
import { ShoppingCart } from 'lucide-react';

const products = [
  {
    id: 1,
    name: "ThinkPad X1 Carbon (Reconditionné)",
    images: [
      "https://images.unsplash.com/photo-1611078489935-0cb964de46d6?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1593642634315-48f5414c3ad9?auto=format&fit=crop&w=1200&q=80"
    ],
    priceHT: "749.17",
    priceTTC: "899",
    specs: ["Intel i7 11ème Gén", "16Go RAM", "512Go SSD", "Écran 14\" 4K"],
    condition: "Grade A",
    eco: "Économise 350kg de CO2",
    description: "Ordinateur portable professionnel parfait pour les entreprises et le travail créatif. Ce ThinkPad X1 Carbon reconditionné offre des performances et une fiabilité exceptionnelles avec un impact environnemental minimal.",
    technicalDetails: "detailed_spec_x1carbon.pdf"
  },
  {
    id: 2,
    name: "Station de Travail Dell OptiPlex",
    images: [
      "https://images.unsplash.com/photo-1593640408182-31c70c8268f5?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1587831990711-23ca6441447b?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1591370874773-6702e8f12fd8?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1591405351990-4726e331f141?auto=format&fit=crop&w=1200&q=80"
    ],
    priceHT: "499.17",
    priceTTC: "599",
    specs: ["Intel i5 10ème Gén", "16Go RAM", "256Go SSD", "Windows 11 Pro"],
    condition: "Grade A",
    eco: "Économise 280kg de CO2",
    description: "Station de travail puissante idéale pour les environnements de bureau. Cet OptiPlex Dell offre des performances fiables et une maintenance facile dans un format compact.",
    technicalDetails: "detailed_spec_optiplex.pdf"
  },
  {
    id: 3,
    name: "HP EliteBook",
    images: [
      "https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1593642634315-48f5414c3ad9?auto=format&fit=crop&w=1200&q=80"
    ],
    priceHT: "582.50",
    priceTTC: "699",
    specs: ["Intel i7 10ème Gén", "16Go RAM", "512Go SSD", "Écran 15.6\" FHD"],
    condition: "Grade A",
    eco: "Économise 320kg de CO2",
    description: "Ordinateur portable haut de gamme alliant performance et mobilité. Le HP EliteBook dispose de fonctionnalités de sécurité de niveau entreprise et d'une durabilité exceptionnelle dans un design élégant.",
    technicalDetails: "detailed_spec_elitebook.pdf"
  },
  {
    id: 4,
    name: "Pack Équipement Réseau",
    images: [
      "https://images.unsplash.com/photo-1587831990711-23ca6441447b?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1591370874773-6702e8f12fd8?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1591405351990-4726e331f141?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1593640408182-31c70c8268f5?auto=format&fit=crop&w=1200&q=80"
    ],
    priceHT: "249.17",
    priceTTC: "299",
    specs: ["Routeur", "Switch", "Point d'accès", "Câbles Cat6"],
    condition: "Grade B+",
    eco: "Économise 150kg de CO2",
    description: "Solution réseau complète pour petites entreprises. Ce pack inclut tous les composants essentiels pour mettre en place une infrastructure réseau fiable et sécurisée.",
    technicalDetails: "detailed_spec_network.pdf"
  }
];

export const Products = () => {
  const [selectedProduct, setSelectedProduct] = useState<typeof products[0] | null>(null);
  const [showCustomPC, setShowCustomPC] = useState(false);
  const { addItem } = useCartStore();
  const { isAuthenticated } = useAuthStore();

  const handleAddToCart = (product: typeof products[0]) => {
    if (!isAuthenticated) {
      alert('Veuillez vous connecter pour ajouter des produits au panier');
      return;
    }
    
    addItem({
      id: product.id,
      name: product.name,
      price: parseFloat(product.priceTTC),
      image: product.images[0],
    });
  };

  return (
    <section id="store" className="py-20 bg-cyber-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-neon mb-4 animate-glow">Matériel Reconditionné</h2>
          <p className="text-neon-blue text-lg max-w-3xl mx-auto">
            Équipement informatique reconditionné certifié avec garantie de qualité et impact écologique réduit
          </p>
          <button
            onClick={() => setShowCustomPC(true)}
            className="mt-8 px-8 py-4 bg-neon text-cyber-black rounded-full font-semibold hover:shadow-neon transition-all"
          >
            Commander un PC Sur Mesure
          </button>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-cyber-black rounded-lg overflow-hidden border border-neon/20 hover:border-neon/50 transition-all group"
            >
              <div className="aspect-w-16 aspect-h-9 relative overflow-hidden">
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="object-cover w-full h-48 group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-2 right-2 bg-neon text-cyber-black px-2 py-1 rounded text-sm font-semibold">
                  {product.condition}
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold text-neon-blue mb-2">{product.name}</h3>
                <ul className="space-y-1 mb-4">
                  {product.specs.map((spec) => (
                    <li key={spec} className="text-sm text-gray-400 flex items-center">
                      <span className="w-1 h-1 bg-neon rounded-full mr-2" />
                      {spec}
                    </li>
                  ))}
                </ul>
                <div className="flex flex-col mb-3">
                  <span className="text-2xl font-bold text-neon">{product.priceTTC}€ TTC</span>
                  <span className="text-lg text-gray-400">{product.priceHT}€ HT</span>
                </div>
                <div className="flex items-center justify-between mb-3 space-x-2">
                  <button
                    onClick={() => setSelectedProduct(product)}
                    className="flex-1 px-4 py-2 bg-transparent border border-neon text-neon rounded hover:bg-neon hover:text-cyber-black transition-all duration-300"
                  >
                    Détails
                  </button>
                  <button
                    onClick={() => handleAddToCart(product)}
                    className="px-4 py-2 bg-neon text-cyber-black rounded hover:shadow-neon transition-all flex items-center"
                  >
                    <ShoppingCart className="w-5 h-5" />
                  </button>
                </div>
                <div className="text-sm text-green-400 bg-green-400/10 py-1 px-2 rounded text-center">
                  ♻️ {product.eco}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <p className="text-gray-300 mb-4">
            Tout notre matériel reconditionné est livré avec :
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-cyber-black p-4 rounded-lg border border-neon/20">
              <p className="text-neon-blue">✓ Garantie Qualité</p>
            </div>
            <div className="bg-cyber-black p-4 rounded-lg border border-neon/20">
              <p className="text-neon-blue">✓ Tests de Performance</p>
            </div>
            <div className="bg-cyber-black p-4 rounded-lg border border-neon/20">
              <p className="text-neon-blue">✓ Support Professionnel</p>
            </div>
          </div>
        </div>
      </div>

      <ProductModal
        product={selectedProduct!}
        isOpen={!!selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />

      <CustomPCBuilder
        isOpen={showCustomPC}
        onClose={() => setShowCustomPC(false)}
      />
    </section>
  );
};