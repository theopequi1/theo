import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

export const Background = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Increased number of particles and adjusted animation range
    const particles = Array.from({ length: 150 }).map(() => {
      const particle = document.createElement('div');
      particle.className = 'fixed w-1 h-1 bg-neon rounded-full opacity-20';
      particle.style.left = `${Math.random() * 100}%`;
      particle.style.top = `${Math.random() * 100}%`;
      return particle;
    });

    particles.forEach(particle => {
      containerRef.current?.appendChild(particle);
      gsap.to(particle, {
        x: 'random(-500, 500)',
        y: 'random(-500, 500)',
        duration: 'random(8, 15)',
        repeat: -1,
        yoyo: true,
        ease: 'none'
      });
    });

    return () => {
      particles.forEach(particle => particle.remove());
    };
  }, []);

  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 w-full min-h-screen bg-gradient-to-br from-cyber-darker via-cyber-dark to-cyber-black overflow-hidden pointer-events-none"
      style={{ zIndex: -1 }}
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(0,255,0,0.05)_0%,_transparent_70%)]" />
    </div>
  );
};