import { motion } from 'framer-motion';
import CountUp from 'react-countup';

const stats = [
  {
    value: 1500,
    label: 'Clients Satisfaits',
    prefix: '+',
  },
  {
    value: 2000,
    label: 'Appareils Réparés',
    prefix: '+',
  },
  {
    value: 95,
    label: 'Satisfaction Client',
    suffix: '%',
  },
  {
    value: 10,
    label: "Années d'Expérience",
    prefix: '+',
  },
];

const testimonials = [
  {
    name: 'Marie Dubois',
    role: 'Chef d\'Entreprise',
    content: 'IGUANE INFORMATIQUE a transformé notre infrastructure IT. Leur expertise et leur professionnalisme sont incomparables.',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150&h=150',
  },
  {
    name: 'Thomas Laurent',
    role: 'Client Particulier',
    content: 'Service excellent ! Ils m\'ont aidé à configurer mon bureau à domicile avec du matériel reconditionné qui fonctionne comme neuf.',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150&h=150',
  },
  {
    name: 'Sophie Martin',
    role: 'Responsable IT',
    content: 'Leurs services managés ont considérablement réduit nos temps d\'arrêt. Hautement recommandé pour les entreprises.',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=150&h=150',
  },
];

export const Stats = () => {
  return (
    <section className="py-20 bg-cyber-black/80 backdrop-blur-sm relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="text-center"
            >
              <h3 className="text-4xl font-bold text-neon mb-2">
                <span>{stat.prefix}</span>
                <CountUp end={stat.value} duration={2.5} />
                <span>{stat.suffix}</span>
              </h3>
              <p className="text-neon-blue">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        {/* Testimonials */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-neon mb-4 animate-glow">Témoignages Clients</h2>
          <p className="text-neon-blue text-lg">Ce que nos clients disent de nous</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-cyber-darker p-6 rounded-lg border border-neon/20 hover:border-neon/50 transition-all"
            >
              <div className="flex items-center mb-4">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full mr-4"
                />
                <div>
                  <h4 className="text-neon-blue font-semibold">{testimonial.name}</h4>
                  <p className="text-gray-400 text-sm">{testimonial.role}</p>
                </div>
              </div>
              <p className="text-gray-300 italic">&ldquo;{testimonial.content}&rdquo;</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};