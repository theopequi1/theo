import { motion, AnimatePresence } from 'framer-motion';
import { X, Cpu, HardDrive, Monitor, Keyboard } from 'lucide-react';
import { useState } from 'react';

interface CustomPCBuilderProps {
  isOpen: boolean;
  onClose: () => void;
}

const components = {
  processors: [
    { id: 1, name: 'AMD Ryzen 5 5600X', price: 299, description: '6 cœurs, 12 threads, 3.7GHz' },
    { id: 2, name: 'Intel Core i5-12600K', price: 329, description: '10 cœurs, 16 threads, 3.7GHz' },
    { id: 3, name: 'AMD Ryzen 7 5800X', price: 449, description: '8 cœurs, 16 threads, 3.8GHz' },
    { id: 4, name: 'Intel Core i7-12700K', price: 479, description: '12 cœurs, 20 threads, 3.6GHz' },
  ],
  motherboards: [
    { id: 1, name: 'MSI B550 GAMING PLUS', price: 139, description: 'AMD AM4, PCIe 4.0, DDR4' },
    { id: 2, name: 'ASUS ROG STRIX B660-F', price: 209, description: 'Intel LGA 1700, PCIe 5.0, DDR5' },
    { id: 3, name: 'GIGABYTE X570 AORUS ELITE', price: 199, description: 'AMD AM4, PCIe 4.0, DDR4' },
    { id: 4, name: 'ASUS TUF GAMING Z690-PLUS', price: 289, description: 'Intel LGA 1700, PCIe 5.0, DDR5' },
  ],
  ram: [
    { id: 1, name: 'Corsair Vengeance 16GB', price: 89, description: '2x8GB, DDR4-3200, CL16' },
    { id: 2, name: 'G.Skill Trident Z5 32GB', price: 219, description: '2x16GB, DDR5-5600, CL36' },
    { id: 3, name: 'Crucial Ballistix 32GB', price: 149, description: '2x16GB, DDR4-3600, CL16' },
    { id: 4, name: 'Kingston FURY Beast 64GB', price: 389, description: '2x32GB, DDR5-5200, CL40' },
  ],
  storage: [
    { id: 1, name: 'Samsung 970 EVO Plus 1TB', price: 119, description: 'NVMe SSD, 3500/3300 MB/s' },
    { id: 2, name: 'WD Black SN850 2TB', price: 299, description: 'NVMe SSD, 7000/5300 MB/s' },
    { id: 3, name: 'Crucial P5 Plus 1TB', price: 159, description: 'NVMe SSD, 6600/5000 MB/s' },
    { id: 4, name: 'Seagate FireCuda 530 2TB', price: 359, description: 'NVMe SSD, 7300/6900 MB/s' },
  ],
  gpus: [
    { id: 1, name: 'NVIDIA RTX 3060 Ti', price: 499, description: '8GB GDDR6, Ray Tracing' },
    { id: 2, name: 'AMD RX 6700 XT', price: 549, description: '12GB GDDR6, AMD RDNA 2' },
    { id: 3, name: 'NVIDIA RTX 3080', price: 899, description: '10GB GDDR6X, DLSS' },
    { id: 4, name: 'AMD RX 6800 XT', price: 749, description: '16GB GDDR6, Smart Access Memory' },
  ],
  cases: [
    { id: 1, name: 'Fractal Design Meshify C', price: 99, description: 'ATX Mid Tower, Noir' },
    { id: 2, name: 'Lian Li O11 Dynamic', price: 159, description: 'ATX Full Tower, Verre Trempé' },
    { id: 3, name: 'NZXT H510 Flow', price: 89, description: 'ATX Mid Tower, Blanc' },
    { id: 4, name: 'be quiet! Dark Base 700', price: 189, description: 'ATX Full Tower, RGB' },
  ],
  psus: [
    { id: 1, name: 'Corsair RM750x', price: 129, description: '750W, 80+ Gold, Modulaire' },
    { id: 2, name: 'be quiet! Straight Power 11', price: 159, description: '850W, 80+ Platinum' },
    { id: 3, name: 'Seasonic FOCUS GX-850', price: 149, description: '850W, 80+ Gold, Modulaire' },
    { id: 4, name: 'EVGA SuperNOVA 1000 G6', price: 199, description: '1000W, 80+ Gold, Modulaire' },
  ],
};

export const CustomPCBuilder = ({ isOpen, onClose }: CustomPCBuilderProps) => {
  const [selectedComponents, setSelectedComponents] = useState<Record<string, any>>({});
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    { name: 'Processeur', icon: Cpu, items: components.processors },
    { name: 'Carte Mère', icon: HardDrive, items: components.motherboards },
    { name: 'Mémoire RAM', icon: Monitor, items: components.ram },
    { name: 'Stockage', icon: HardDrive, items: components.storage },
    { name: 'Carte Graphique', icon: Monitor, items: components.gpus },
    { name: 'Boîtier', icon: Keyboard, items: components.cases },
    { name: 'Alimentation', icon: HardDrive, items: components.psus },
  ];

  const totalPrice = Object.values(selectedComponents).reduce((sum, item) => sum + (item?.price || 0), 0);

  const handleSelectComponent = (component: any) => {
    setSelectedComponents(prev => ({
      ...prev,
      [steps[currentStep].name]: component
    }));
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm"
          onClick={onClose}
        />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-cyber-black border border-neon/20 rounded-lg w-full max-w-6xl max-h-[90vh] overflow-y-auto relative z-50"
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-neon hover:text-neon-blue transition-colors"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="p-6">
            <h2 className="text-2xl font-bold text-neon mb-6">Configurateur PC Sur Mesure</h2>

            {/* Progress Bar */}
            <div className="mb-8">
              <div className="flex justify-between mb-2">
                {steps.map((step, index) => (
                  <div
                    key={step.name}
                    className={`flex items-center ${
                      index <= currentStep ? 'text-neon' : 'text-gray-500'
                    }`}
                  >
                    <step.icon className="w-5 h-5" />
                    <span className="ml-2 text-sm hidden md:inline">{step.name}</span>
                  </div>
                ))}
              </div>
              <div className="h-2 bg-cyber-darker rounded-full">
                <div
                  className="h-full bg-neon rounded-full transition-all duration-300"
                  style={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }}
                />
              </div>
            </div>

            {/* Component Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-xl font-semibold text-neon-blue mb-4">
                  {steps[currentStep].name}
                </h3>
                <div className="space-y-4">
                  {steps[currentStep].items.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => handleSelectComponent(item)}
                      className={`w-full p-4 rounded-lg border ${
                        selectedComponents[steps[currentStep].name]?.id === item.id
                          ? 'border-neon bg-neon/10'
                          : 'border-neon/20 hover:border-neon/50'
                      } transition-all`}
                    >
                      <div className="flex justify-between items-center">
                        <div className="text-left">
                          <h4 className="text-neon-blue font-semibold">{item.name}</h4>
                          <p className="text-gray-400 text-sm">{item.description}</p>
                        </div>
                        <span className="text-neon font-bold">{item.price}€</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Selected Components Summary */}
              <div>
                <h3 className="text-xl font-semibold text-neon-blue mb-4">Configuration</h3>
                <div className="bg-cyber-darker p-4 rounded-lg">
                  {Object.entries(selectedComponents).map(([name, component]) => (
                    <div key={name} className="flex justify-between items-center py-2 border-b border-neon/10 last:border-0">
                      <div>
                        <p className="text-neon-blue">{name}</p>
                        <p className="text-sm text-gray-400">{component.name}</p>
                      </div>
                      <span className="text-neon">{component.price}€</span>
                    </div>
                  ))}
                  <div className="mt-4 pt-4 border-t border-neon/20">
                    <div className="flex justify-between items-center">
                      <span className="text-neon-blue font-semibold">Total TTC</span>
                      <span className="text-2xl font-bold text-neon">{totalPrice}€</span>
                    </div>
                  </div>
                </div>

                {currentStep === steps.length - 1 && (
                  <button
                    className="w-full mt-6 py-3 bg-neon text-cyber-black rounded-lg font-semibold hover:shadow-neon transition-all"
                    onClick={() => {
                      // Handle order submission
                      alert('Votre commande a été enregistrée. Nous vous contacterons rapidement pour finaliser votre configuration.');
                      onClose();
                    }}
                  >
                    Commander
                  </button>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};