import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { motion } from 'framer-motion';

const data = [
  { name: 'Power Supply Failures', value: 30, color: '#00FF00' },
  { name: 'CPU Overheating', value: 25, color: '#00FFFF' },
  { name: 'Blue Screen Errors', value: 20, color: '#0088FE' },
  { name: 'Malware Infections', value: 25, color: '#FF00FF' },
];

export const IssuesChart = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="bg-cyber-black p-6 rounded-lg border border-neon/20"
    >
      <h3 className="text-2xl font-bold text-neon mb-6 text-center">Common IT Issues</h3>
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={80}
              paddingAngle={5}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: '#1A1A1A',
                border: '1px solid #00FF00',
                borderRadius: '4px',
              }}
            />
            <Legend
              verticalAlign="bottom"
              height={36}
              formatter={(value) => <span className="text-neon-blue">{value}</span>}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
};