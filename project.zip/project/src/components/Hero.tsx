import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import gsap from 'gsap';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Hero = () => {
  const titleRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (!titleRef.current) return;

    gsap.from(titleRef.current.children, {
      y: 100,
      opacity: 0,
      duration: 1,
      stagger: 0.2,
      ease: "power4.out"
    });
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <h1 
            ref={titleRef}
            className="text-4xl md:text-6xl lg:text-7xl font-bold text-neon mb-8 animate-glow"
          >
            <span className="block">Solutions Informatiques</span>
            <span className="block">Nouvelle Génération</span>
          </h1>

          <p className="text-neon-blue text-xl md:text-2xl max-w-3xl mx-auto mb-12">
            Construisons votre avenir numérique avec des technologies de pointe et des solutions durables
          </p>

          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Link 
              to="/professional"
              className="px-8 py-4 bg-neon text-cyber-black rounded-full font-semibold flex items-center justify-center gap-2 hover:shadow-neon transition-all group"
            >
              Découvrir nos Services
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              to="/store" 
              className="px-8 py-4 border-2 border-neon-blue text-neon-blue rounded-full font-semibold hover:shadow-neon-blue transition-all hover:bg-neon-blue/10"
            >
              Voir nos Produits
            </Link>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};