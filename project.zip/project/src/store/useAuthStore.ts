import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface BusinessInfo {
  companyName: string;
  siret: string;
  vatNumber: string;
  businessAddress: string;
}

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  role: 'client' | 'admin';
  businessInfo?: BusinessInfo;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (user: User) => void;
  logout: () => void;
  updateBusinessInfo: (businessInfo: BusinessInfo) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      login: (user) => set({ user, isAuthenticated: true }),
      logout: () => set({ user: null, isAuthenticated: false }),
      updateBusinessInfo: (businessInfo) =>
        set((state) => ({
          user: state.user ? { ...state.user, businessInfo } : null,
        })),
    }),
    {
      name: 'auth-storage',
    }
  )
);