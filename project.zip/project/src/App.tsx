import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Professional } from './pages/Professional';
import { Individual } from './pages/Individual';
import { Products } from './components/Products';
import { Contact } from './pages/Contact';
import { Background } from './components/Background';
import { Dashboard } from './pages/client/Dashboard';
import { Orders } from './pages/client/Orders';
import { BusinessInfo } from './pages/client/BusinessInfo';

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="relative min-h-screen">
        <Background />
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="professional" element={<Professional />} />
            <Route path="individual" element={<Individual />} />
            <Route path="store" element={<Products />} />
            <Route path="contact" element={<Contact />} />
            <Route path="client/dashboard" element={<Dashboard />} />
            <Route path="client/orders" element={<Orders />} />
            <Route path="client/business" element={<BusinessInfo />} />
          </Routes>
        </Layout>
      </div>
    </Router>
  );
}

export default App;