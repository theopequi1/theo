import { motion } from 'framer-motion';
import { Monitor, Wrench, Cpu, GraduationCap, Shield, Clock, PenTool as Tool, Laptop } from 'lucide-react';
import { ServicePricing } from '../components/ServicePricing';

const services = [
  {
    icon: Monitor,
    title: 'Support Informatique',
    description: 'Support informatique expert à domicile ou en boutique.',
    features: [
      'Réparation matérielle',
      'Dépannage logiciel',
      'Optimisation système',
      'Récupération de données',
    ]
  },
  {
    icon: Wrench,
    title: 'Services d\'Installation',
    description: 'Installation professionnelle de matériel et logiciel.',
    features: [
      'Installation système d\'exploitation',
      'Configuration logicielle',
      'Installation périphériques',
      'Configuration réseau',
    ]
  },
  {
    icon: Cpu,
    title: 'Maintenance Système',
    description: 'Gardez votre ordinateur performant.',
    features: [
      'Nettoyage système',
      'Optimisation performances',
      'Suppression virus',
      'Maintenance régulière',
    ]
  },
  {
    icon: GraduationCap,
    title: 'Formation & Assistance',
    description: 'Apprenez à utiliser efficacement votre technologie.',
    features: [
      'Compétences informatiques de base',
      'Formation logicielle',
      'Sensibilisation à la sécurité',
      'Accompagnement personnalisé',
    ]
  }
];

const benefits = [
  {
    icon: Clock,
    title: 'Service Rapide',
    description: 'Intervention le jour même ou le lendemain',
  },
  {
    icon: Shield,
    title: 'Garantie Qualité',
    description: 'Toutes les réparations sont garanties satisfaction',
  },
  {
    icon: Tool,
    title: 'Techniciens Experts',
    description: 'Professionnels certifiés avec des années d\'expérience',
  },
  {
    icon: Laptop,
    title: 'Service à Domicile',
    description: 'Réparations pratiques à votre domicile',
  },
];

const faq = [
  {
    question: 'Comment fonctionne la réduction d\'impôts de 50% ?',
    answer: 'La réduction d\'impôts s\'applique à tous nos services pour les particuliers. Vous payez le montant total initialement, et 50% du coût peut être déduit de vos impôts. Nous fournissons toute la documentation nécessaire pour votre déclaration fiscale.',
  },
  {
    question: 'Proposez-vous des services d\'urgence ?',
    answer: 'Oui, nous fournissons des services de support informatique d\'urgence avec des temps de réponse prioritaires. Des frais supplémentaires peuvent s\'appliquer pour les urgences en dehors des heures ouvrables ou le week-end.',
  },
  {
    question: 'Quelles zones couvrez-vous ?',
    answer: 'Nous servons toute la région métropolitaine de Toulouse et les communautés environnantes dans un rayon de 30km. Des frais de déplacement peuvent s\'appliquer pour les localisations en dehors de notre zone de service principale.',
  },
  {
    question: 'Combien de temps prend une réparation typique ?',
    answer: 'La plupart des réparations courantes peuvent être effectuées en 24-48 heures. Les problèmes complexes peuvent nécessiter plus de temps. Nous fournissons toujours une estimation du temps de réparation avant de commencer les travaux.',
  },
];

export const Individual = () => {
  return (
    <div className="pt-20 bg-cyber-darker">
      {/* Hero Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-neon mb-4 animate-glow">
              Services aux Particuliers
            </h1>
            <p className="text-neon-blue text-lg max-w-3xl mx-auto mb-4">
              Support informatique professionnel pour particuliers avec 50% de réduction d'impôts
            </p>
            <div className="inline-block bg-neon/10 px-6 py-3 rounded-full border border-neon">
              <span className="text-neon font-semibold">✨ 50% de Réduction d'Impôts Disponible</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-cyber-black/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-cyber-darker p-6 rounded-lg border border-neon/20 hover:border-neon/50 transition-all"
              >
                <div className="flex items-center mb-4">
                  <service.icon className="w-8 h-8 text-neon mr-3" />
                  <h3 className="text-xl font-semibold text-neon-blue">{service.title}</h3>
                </div>
                <p className="text-gray-400 mb-4">{service.description}</p>
                <ul className="space-y-2">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center text-gray-300">
                      <span className="w-1.5 h-1.5 bg-neon rounded-full mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-cyber-darker">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-neon mb-4">Pourquoi Nous Choisir</h2>
            <p className="text-neon-blue">Le choix préféré pour les services informatiques à domicile à Toulouse</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="text-center p-6 bg-cyber-black rounded-lg border border-neon/20"
              >
                <benefit.icon className="w-12 h-12 text-neon mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-neon-blue mb-2">{benefit.title}</h3>
                <p className="text-gray-400">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Pricing */}
      <ServicePricing />

      {/* FAQ Section */}
      <section className="py-20 bg-cyber-black/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-neon mb-4">Questions Fréquentes</h2>
            <p className="text-neon-blue">Trouvez les réponses aux questions courantes sur nos services</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {faq.map((item, index) => (
              <motion.div
                key={item.question}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-cyber-darker p-6 rounded-lg border border-neon/20"
              >
                <h3 className="text-xl font-semibold text-neon-blue mb-3">{item.question}</h3>
                <p className="text-gray-300">{item.answer}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-20 bg-cyber-darker">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-3xl font-bold text-neon mb-4">Besoin d'Aide avec Votre Ordinateur ?</h2>
            <p className="text-neon-blue mb-8">
              Prenez rendez-vous aujourd'hui et obtenez une assistance professionnelle pour tout problème informatique
            </p>
            <a
              href="/contact"
              className="inline-block px-8 py-4 bg-neon text-cyber-black rounded-full font-semibold hover:shadow-neon transition-all"
            >
              Prendre Rendez-vous
            </a>
          </motion.div>
        </div>
      </section>
    </div>
  );
};