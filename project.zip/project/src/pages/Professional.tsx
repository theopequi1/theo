import { motion } from 'framer-motion';
import { Shield, Server, Cloud, PenTool as Tool, LineChart, Users, Clock, Laptop } from 'lucide-react';
import { ServicePricing } from '../components/ServicePricing';

const services = [
  {
    icon: Shield,
    title: 'Solutions de Cybersécurité',
    description: 'Mesures de sécurité de niveau entreprise pour protéger vos actifs.',
    features: [
      'Évaluation de la sécurité réseau',
      'Configuration pare-feu',
      'Chiffrement des données',
      'Formation à la sécurité',
    ]
  },
  {
    icon: Server,
    title: 'Infrastructure IT',
    description: 'Solutions d\'infrastructure robustes et évolutives pour votre entreprise.',
    features: [
      'Déploiement serveur',
      'Optimisation réseau',
      'Maintenance matérielle',
      'Surveillance système',
    ]
  },
  {
    icon: Cloud,
    title: 'Services Cloud',
    description: 'Solutions cloud modernes pour une efficacité accrue.',
    features: [
      'Migration cloud',
      'Configuration cloud hybride',
      'Sécurité cloud',
      'Optimisation performances',
    ]
  },
  {
    icon: Tool,
    title: 'Services Managés',
    description: 'Support et maintenance 24/7 pour vos systèmes IT.',
    features: [
      'Surveillance proactive',
      'Maintenance régulière',
      'Support helpdesk',
      'Mises à jour système',
    ]
  }
];

const benefits = [
  {
    icon: LineChart,
    title: 'Efficacité Accrue',
    description: 'Optimisez vos opérations avec nos solutions IT sur mesure.',
  },
  {
    icon: Users,
    title: 'Équipe Expert',
    description: 'Accès à des professionnels IT certifiés 24/7.',
  },
  {
    icon: Clock,
    title: 'Temps de Réponse Rapide',
    description: 'Temps de réponse moyen inférieur à 2 heures pour les problèmes critiques.',
  },
  {
    icon: Laptop,
    title: 'Solutions Modernes',
    description: 'Restez à la pointe avec les dernières technologies.',
  },
];

const maintenancePlans = [
  {
    name: 'Pack 5 Heures',
    priceHT: '375',
    priceTTC: '450',
    features: [
      '5 heures de support technique',
      'Assistance à distance prioritaire',
      'Support sur site',
      'Validité 12 mois',
    ],
  },
  {
    name: 'Pack 10 Heures',
    priceHT: '700',
    priceTTC: '840',
    features: [
      '10 heures de support technique',
      'Assistance à distance prioritaire',
      'Support sur site',
      'Validité 12 mois',
    ],
    highlighted: true,
  },
  {
    name: 'Pack 20 Heures',
    priceHT: '1300',
    priceTTC: '1560',
    features: [
      '20 heures de support technique',
      'Assistance à distance prioritaire',
      'Support sur site',
      'Validité 12 mois',
    ],
  },
  {
    name: 'Pack 50 Heures',
    priceHT: '3000',
    priceTTC: '3600',
    features: [
      '50 heures de support technique',
      'Assistance à distance prioritaire',
      'Support sur site illimité',
      'Validité 12 mois',
    ],
  },
];

export const Professional = () => {
  return (
    <div className="pt-20 bg-cyber-darker">
      {/* Hero Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-neon mb-4 animate-glow">
              Solutions IT Professionnelles
            </h1>
            <p className="text-neon-blue text-lg max-w-3xl mx-auto">
              Services informatiques complets adaptés aux entreprises de toutes tailles
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-cyber-black/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-cyber-darker p-6 rounded-lg border border-neon/20 hover:border-neon/50 transition-all"
              >
                <div className="flex items-center mb-4">
                  <service.icon className="w-8 h-8 text-neon mr-3" />
                  <h3 className="text-xl font-semibold text-neon-blue">{service.title}</h3>
                </div>
                <p className="text-gray-400 mb-4">{service.description}</p>
                <ul className="space-y-2">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center text-gray-300">
                      <span className="w-1.5 h-1.5 bg-neon rounded-full mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-cyber-darker">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-neon mb-4">Pourquoi Nous Choisir</h2>
            <p className="text-neon-blue">Découvrez la différence avec nos services IT professionnels</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="text-center p-6 bg-cyber-black rounded-lg border border-neon/20"
              >
                <benefit.icon className="w-12 h-12 text-neon mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-neon-blue mb-2">{benefit.title}</h3>
                <p className="text-gray-400">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Pricing */}
      <ServicePricing />

      {/* Maintenance Plans */}
      <section className="py-20 bg-cyber-darker">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-neon mb-4">Contrats de Maintenance</h2>
            <p className="text-neon-blue">Choisissez le forfait adapté à vos besoins</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {maintenancePlans.map((plan, index) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`p-6 rounded-lg border ${
                  plan.highlighted
                    ? 'border-neon bg-cyber-black/60'
                    : 'border-neon/20 bg-cyber-black/40'
                }`}
              >
                <div className="text-center mb-8">
                  <h3 className="text-xl font-semibold text-neon-blue mb-2">{plan.name}</h3>
                  <div className="text-3xl font-bold text-neon">
                    {plan.priceTTC}€
                    <span className="text-sm text-gray-400 ml-1">TTC</span>
                  </div>
                  <div className="text-lg text-gray-400">
                    {plan.priceHT}€
                    <span className="text-sm ml-1">HT</span>
                  </div>
                </div>

                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center text-gray-300">
                      <span className="w-1.5 h-1.5 bg-neon rounded-full mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-20 bg-cyber-black/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-3xl font-bold text-neon mb-4">Prêt à Transformer Votre Entreprise ?</h2>
            <p className="text-neon-blue mb-8">
              Contactez-nous aujourd'hui pour une consultation gratuite et découvrez comment nous pouvons aider votre entreprise à prospérer
            </p>
            <a
              href="/contact"
              className="inline-block px-8 py-4 bg-neon text-cyber-black rounded-full font-semibold hover:shadow-neon transition-all"
            >
              Planifier une Consultation
            </a>
          </motion.div>
        </div>
      </section>
    </div>
  );
};