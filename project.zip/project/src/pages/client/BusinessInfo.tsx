import { motion } from 'framer-motion';
import { useState } from 'react';
import { useAuthStore } from '../../store/useAuthStore';
import { Building2, Save } from 'lucide-react';

export const BusinessInfo = () => {
  const { user, updateBusinessInfo } = useAuthStore();
  const [formData, setFormData] = useState({
    companyName: user?.businessInfo?.companyName || '',
    siret: user?.businessInfo?.siret || '',
    vatNumber: user?.businessInfo?.vatNumber || '',
    businessAddress: user?.businessInfo?.businessAddress || '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusinessInfo(formData);
    alert('Informations entreprise mises à jour avec succès !');
  };

  return (
    <div className="min-h-screen bg-cyber-darker pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h1 className="text-4xl font-bold text-neon mb-4">
            Informations Entreprise
          </h1>
          <p className="text-neon-blue">
            Gérez les informations de votre entreprise
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-cyber-black p-8 rounded-lg border border-neon/20"
        >
          <div className="flex items-center mb-8">
            <Building2 className="w-8 h-8 text-neon mr-4" />
            <h2 className="text-2xl font-semibold text-neon-blue">
              Détails de l'Entreprise
            </h2>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="companyName" className="block text-gray-300 mb-2">
                Nom de l'entreprise
              </label>
              <input
                type="text"
                id="companyName"
                value={formData.companyName}
                onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                className="w-full bg-cyber-darker border border-neon/20 rounded p-3 text-gray-300 focus:border-neon focus:outline-none"
                required
              />
            </div>

            <div>
              <label htmlFor="siret" className="block text-gray-300 mb-2">
                Numéro SIRET
              </label>
              <input
                type="text"
                id="siret"
                value={formData.siret}
                onChange={(e) => setFormData({ ...formData, siret: e.target.value })}
                className="w-full bg-cyber-darker border border-neon/20 rounded p-3 text-gray-300 focus:border-neon focus:outline-none"
                required
              />
            </div>

            <div>
              <label htmlFor="vatNumber" className="block text-gray-300 mb-2">
                Numéro de TVA
              </label>
              <input
                type="text"
                id="vatNumber"
                value={formData.vatNumber}
                onChange={(e) => setFormData({ ...formData, vatNumber: e.target.value })}
                className="w-full bg-cyber-darker border border-neon/20 rounded p-3 text-gray-300 focus:border-neon focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="businessAddress" className="block text-gray-300 mb-2">
                Adresse de l'entreprise
              </label>
              <textarea
                id="businessAddress"
                value={formData.businessAddress}
                onChange={(e) => setFormData({ ...formData, businessAddress: e.target.value })}
                rows={3}
                className="w-full bg-cyber-darker border border-neon/20 rounded p-3 text-gray-300 focus:border-neon focus:outline-none"
                required
              />
            </div>

            <button
              type="submit"
              className="flex items-center justify-center w-full bg-neon text-cyber-black font-semibold py-3 rounded hover:shadow-neon transition-all"
            >
              <Save className="w-5 h-5 mr-2" />
              Enregistrer les modifications
            </button>
          </form>
        </motion.div>
      </div>
    </div>
  );
};