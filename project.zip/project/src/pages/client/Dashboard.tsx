import { motion } from 'framer-motion';
import { useAuthStore } from '../../store/useAuthStore';
import { Settings, Package, Building2, CreditCard } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Dashboard = () => {
  const { user } = useAuthStore();

  const menuItems = [
    {
      icon: Package,
      title: 'Suivi des Commandes',
      description: 'Consultez l\'état de vos commandes',
      link: '/client/orders',
    },
    {
      icon: Building2,
      title: 'Informations Entreprise',
      description: 'Gérez vos informations professionnelles',
      link: '/client/business',
    },
    {
      icon: Settings,
      title: 'Paramètres du Compte',
      description: 'Modifiez vos informations personnelles',
      link: '/client/settings',
    },
    {
      icon: CreditCard,
      title: 'Facturation',
      description: 'Consultez vos factures',
      link: '/client/billing',
    },
  ];

  return (
    <div className="min-h-screen bg-cyber-darker pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h1 className="text-4xl font-bold text-neon mb-4">
            Bonjour, {user?.firstName} 👋
          </h1>
          <p className="text-neon-blue">
            Bienvenue dans votre espace client
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {menuItems.map((item, index) => (
            <Link to={item.link} key={item.title}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-cyber-black p-6 rounded-lg border border-neon/20 hover:border-neon/50 transition-all group"
              >
                <item.icon className="w-8 h-8 text-neon mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-xl font-semibold text-neon-blue mb-2">
                  {item.title}
                </h3>
                <p className="text-gray-400">
                  {item.description}
                </p>
              </motion.div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};