import { motion } from 'framer-motion';
import { Package, Clock, CheckCircle, AlertCircle } from 'lucide-react';

const orders = [
  {
    id: 'CMD-001',
    date: '2024-03-15',
    status: 'completed',
    items: ['PC Sur Mesure - Config Gaming'],
    total: '1599.99',
  },
  {
    id: 'CMD-002',
    date: '2024-03-10',
    status: 'processing',
    items: ['Service Maintenance - 10h'],
    total: '840.00',
  },
  {
    id: 'CMD-003',
    date: '2024-03-05',
    status: 'pending',
    items: ['Installation Windows', 'Récupération Données'],
    total: '128.00',
  },
];

const getStatusInfo = (status: string) => {
  switch (status) {
    case 'completed':
      return {
        icon: CheckCircle,
        text: 'Terminée',
        color: 'text-green-400',
        bgColor: 'bg-green-400/10',
      };
    case 'processing':
      return {
        icon: Clock,
        text: 'En cours',
        color: 'text-yellow-400',
        bgColor: 'bg-yellow-400/10',
      };
    default:
      return {
        icon: AlertCircle,
        text: 'En attente',
        color: 'text-blue-400',
        bgColor: 'bg-blue-400/10',
      };
  }
};

export const Orders = () => {
  return (
    <div className="min-h-screen bg-cyber-darker pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h1 className="text-4xl font-bold text-neon mb-4">
            Suivi des Commandes
          </h1>
          <p className="text-neon-blue">
            Consultez l'état de vos commandes et leur historique
          </p>
        </motion.div>

        <div className="space-y-6">
          {orders.map((order, index) => {
            const status = getStatusInfo(order.status);
            return (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-cyber-black p-6 rounded-lg border border-neon/20"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-4">
                    <Package className="w-6 h-6 text-neon" />
                    <div>
                      <h3 className="text-xl font-semibold text-neon-blue">
                        Commande {order.id}
                      </h3>
                      <p className="text-gray-400">
                        {new Date(order.date).toLocaleDateString('fr-FR')}
                      </p>
                    </div>
                  </div>
                  <div className={`px-4 py-2 rounded-full ${status.bgColor}`}>
                    <div className="flex items-center space-x-2">
                      <status.icon className={`w-4 h-4 ${status.color}`} />
                      <span className={status.color}>{status.text}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  {order.items.map((item, i) => (
                    <div key={i} className="text-gray-300">
                      • {item}
                    </div>
                  ))}
                </div>

                <div className="mt-4 pt-4 border-t border-neon/20 flex justify-between items-center">
                  <span className="text-gray-400">Total TTC</span>
                  <span className="text-2xl font-bold text-neon">
                    {order.total}€
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};