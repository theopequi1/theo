import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, Clock, Star, MessageSquare, Calendar } from 'lucide-react';
import CountUp from 'react-countup';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import { useState } from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

const reviews = [
  {
    name: "Sophie Martin",
    role: "Chef d'Entreprise",
    rating: 5,
    comment: "Excellent service ! Ils ont aidé à configurer tout notre réseau de bureau efficacement.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150&h=150"
  },
  {
    name: "Thomas Laurent",
    role: "Freelance",
    rating: 5,
    comment: "Équipe professionnelle et compétente. Temps de réponse rapide pour les urgences.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150&h=150"
  },
  {
    name: "Marie Dubois",
    role: "Étudiante",
    rating: 5,
    comment: "Excellent rapport qualité-prix. Ils ont sauvé ma thèse quand mon ordinateur portable a planté !",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=150&h=150"
  }
];

const funFacts = [
  { number: 42000, label: "Heures de Support" },
  { number: 15000, label: "Ordinateurs Réparés" },
  { number: 99.9, label: "% Satisfaction Client" },
  { number: 24, label: "Heures de Délai de Réponse" }
];

const availableTimeSlots = {
  '1': ['09:00', '10:30', '14:00', '15:30', '17:00'], // Lundi
  '2': ['09:00', '11:00', '14:00', '16:00'], // Mardi
  '3': ['10:00', '11:30', '14:30', '16:30'], // Mercredi
  '4': ['09:00', '10:30', '14:00', '15:30', '17:00'], // Jeudi
  '5': ['09:00', '11:00', '14:00', '16:00'], // Vendredi
};

export const Contact = () => {
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [showTimeSlots, setShowTimeSlots] = useState(false);

  const handleDateSelect = (selectInfo: any) => {
    const date = new Date(selectInfo.start);
    const dayOfWeek = date.getDay().toString();
    
    if (dayOfWeek in availableTimeSlots && dayOfWeek !== '0' && dayOfWeek !== '6') {
      setSelectedDate(date);
      setShowTimeSlots(true);
    } else {
      alert('Veuillez sélectionner un jour de semaine pour la prise de rendez-vous.');
    }
  };

  const getAvailableTimesForDate = () => {
    if (!selectedDate) return [];
    const dayOfWeek = selectedDate.getDay().toString();
    return availableTimeSlots[dayOfWeek as keyof typeof availableTimeSlots] || [];
  };

  return (
    <div className="pt-20 bg-cyber-darker">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-neon mb-4 animate-glow">
            Contactez-nous
          </h1>
          <p className="text-neon-blue text-lg max-w-3xl mx-auto">
            Prenez contact avec notre équipe pour un support informatique professionnel
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Informations de Contact */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-8"
          >
            <div className="bg-cyber-black p-6 rounded-lg border border-neon/20">
              <h2 className="text-2xl font-semibold text-neon-blue mb-6">Informations de Contact</h2>
              <div className="space-y-4">
                <div className="flex items-center">
                  <Phone className="w-6 h-6 text-neon mr-4" />
                  <div>
                    <p className="text-gray-300">Ligne Fixe</p>
                    <p className="text-neon-blue font-semibold">05 82 95 09 25</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Phone className="w-6 h-6 text-neon mr-4" />
                  <div>
                    <p className="text-gray-300">Mobile</p>
                    <p className="text-neon-blue font-semibold">06 14 65 71 31</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Mail className="w-6 h-6 text-neon mr-4" />
                  <div>
                    <p className="text-gray-300">Email</p>
                    <p className="text-neon-blue font-semibold">contact@iguane-informatique.fr</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <MapPin className="w-6 h-6 text-neon mr-4" />
                  <div>
                    <p className="text-gray-300">Adresse</p>
                    <p className="text-neon-blue font-semibold">Toulouse, France</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Clock className="w-6 h-6 text-neon mr-4" />
                  <div>
                    <p className="text-gray-300">Horaires d'Ouverture</p>
                    <p className="text-neon-blue">Lundi - Vendredi : 9h00 - 18h00</p>
                    <p className="text-neon-blue">Samedi : Sur rendez-vous</p>
                    <p className="text-neon-blue">Dimanche : Fermé</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Carte Interactive */}
            <div className="bg-cyber-black p-6 rounded-lg border border-neon/20">
              <h2 className="text-2xl font-semibold text-neon-blue mb-6">Nous Trouver</h2>
              <div className="relative w-full h-[300px] rounded-lg overflow-hidden">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d92456.55891477017!2d1.3628111767211785!3d43.60080771054055!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12aebb6fec7552ff%3A0x406f69c2f411030!2sToulouse%2C%20France!5e0!3m2!1sen!2sus!4v1645509721053!5m2!1sen!2sus"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            </div>
          </motion.div>

          {/* Formulaire de Contact et Calendrier */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-8"
          >
            {/* Calendrier de Rendez-vous */}
            <div className="bg-cyber-black p-6 rounded-lg border border-neon/20">
              <h2 className="text-2xl font-semibold text-neon-blue mb-6">Prendre Rendez-vous</h2>
              <div className="mb-6">
                <FullCalendar
                  plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
                  initialView="dayGridMonth"
                  locale="fr"
                  selectable={true}
                  select={handleDateSelect}
                  headerToolbar={{
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek'
                  }}
                  buttonText={{
                    today: "Aujourd'hui",
                    month: 'Mois',
                    week: 'Semaine'
                  }}
                  businessHours={{
                    daysOfWeek: [1, 2, 3, 4, 5],
                    startTime: '09:00',
                    endTime: '18:00',
                  }}
                  selectConstraint="businessHours"
                />
              </div>

              {showTimeSlots && selectedDate && (
                <div className="mt-4">
                  <h3 className="text-neon-blue font-semibold mb-2">
                    Créneaux disponibles pour le {format(selectedDate, 'dd MMMM yyyy', { locale: fr })}
                  </h3>
                  <div className="grid grid-cols-3 gap-2">
                    {getAvailableTimesForDate().map((time) => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`p-2 rounded ${
                          selectedTime === time
                            ? 'bg-neon text-cyber-black'
                            : 'border border-neon/20 text-neon-blue hover:border-neon'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                  {selectedTime && (
                    <button
                      onClick={() => {
                        alert('Rendez-vous demandé ! Nous vous contacterons pour confirmer.');
                        setSelectedDate(null);
                        setSelectedTime(null);
                        setShowTimeSlots(false);
                      }}
                      className="w-full mt-4 bg-neon text-cyber-black font-semibold py-2 rounded hover:shadow-neon transition-all"
                    >
                      Confirmer le Rendez-vous
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Formulaire de Contact */}
            <div className="bg-cyber-black p-6 rounded-lg border border-neon/20">
              <h2 className="text-2xl font-semibold text-neon-blue mb-6">Envoyez-nous un Message</h2>
              <form className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-gray-300 mb-2">
                    Nom
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="w-full bg-cyber-darker border border-neon/20 rounded p-3 text-gray-300 focus:border-neon focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-gray-300 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full bg-cyber-darker border border-neon/20 rounded p-3 text-gray-300 focus:border-neon focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-gray-300 mb-2">
                    Téléphone
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    className="w-full bg-cyber-darker border border-neon/20 rounded p-3 text-gray-300 focus:border-neon focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-gray-300 mb-2">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full bg-cyber-darker border border-neon/20 rounded p-3 text-gray-300 focus:border-neon focus:outline-none"
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full bg-neon text-cyber-black font-semibold py-3 rounded hover:shadow-neon transition-all"
                >
                  Envoyer le Message
                </button>
              </form>
            </div>
          </motion.div>
        </div>

        {/* Statistiques */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="mt-20"
        >
          <h2 className="text-3xl font-bold text-neon text-center mb-12">Chiffres Clés</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {funFacts.map((fact, index) => (
              <div
                key={fact.label}
                className="text-center bg-cyber-black p-6 rounded-lg border border-neon/20"
              >
                <CountUp
                  end={fact.number}
                  duration={2.5}
                  decimals={fact.number % 1 !== 0 ? 1 : 0}
                  className="text-3xl font-bold text-neon"
                />
                <p className="text-neon-blue mt-2">{fact.label}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Avis Clients */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="mt-20"
        >
          <h2 className="text-3xl font-bold text-neon text-center mb-12">Avis Clients</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {reviews.map((review, index) => (
              <motion.div
                key={review.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-cyber-black p-6 rounded-lg border border-neon/20"
              >
                <div className="flex items-center mb-4">
                  <img
                    src={review.image}
                    alt={review.name}
                    className="w-12 h-12 rounded-full mr-4"
                  />
                  <div>
                    <h4 className="text-neon-blue font-semibold">{review.name}</h4>
                    <p className="text-gray-400 text-sm">{review.role}</p>
                  </div>
                </div>
                <div className="flex mb-3">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-neon fill-neon" />
                  ))}
                </div>
                <p className="text-gray-300">{review.comment}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Chat Rapide */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="mt-20 text-center"
        >
          <div className="bg-cyber-black p-8 rounded-lg border border-neon/20 relative overflow-hidden group cursor-pointer">
            <div className="relative z-10">
              <MessageSquare className="w-16 h-16 text-neon mx-auto mb-4 transform group-hover:scale-110 transition-transform" />
              <h3 className="text-2xl font-bold text-neon mb-4">Discussion Rapide</h3>
              <p className="text-neon-blue mb-6">
                Besoin d'une assistance immédiate ? Démarrez une conversation avec notre assistant !
              </p>
              <button className="px-8 py-3 bg-neon text-cyber-black rounded-full font-semibold hover:shadow-neon transition-all">
                Démarrer la Discussion
              </button>
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-neon/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </motion.div>
      </div>
    </div>
  );
};