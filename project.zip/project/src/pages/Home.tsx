import { Hero } from '../components/Hero';
import { Services } from '../components/Services';
import { Products } from '../components/Products';
import { Stats } from '../components/Stats';
import { ServicePricing } from '../components/ServicePricing';

export const Home = () => {
  return (
    <>
      <Hero />
      <div className="relative z-10">
        <Services />
        <Stats />
        <ServicePricing />
        <Products />
      </div>
    </>
  );
};