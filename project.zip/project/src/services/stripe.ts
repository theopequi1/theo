import { loadStripe } from '@stripe/stripe-js';

// Remplacez par votre clé publique Stripe
const stripePromise = loadStripe('votre_cle_publique_stripe');

export const initiatePayment = async (amount: number, description: string) => {
  try {
    const stripe = await stripePromise;
    if (!stripe) throw new Error('Stripe n\'a pas pu être initialisé');

    // Cette partie devrait communiquer avec votre backend pour créer une session de paiement
    const response = await fetch('/api/create-payment-session', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount,
        description,
      }),
    });

    const session = await response.json();

    const result = await stripe.redirectToCheckout({
      sessionId: session.id,
    });

    if (result.error) {
      throw new Error(result.error.message);
    }
  } catch (error) {
    console.error('Erreur lors de l\'initiation du paiement:', error);
    throw error;
  }
};