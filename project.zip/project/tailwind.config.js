/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        neon: {
          green: '#00FF00',
          blue: '#00FFFF',
          DEFAULT: '#00FF00'
        },
        cyber: {
          black: '#000000',
          dark: '#1A1A1A',
          darker: '#0A0A0A'
        }
      },
      animation: {
        'gradient': 'gradient 8s linear infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
        'pulse-neon': 'pulse-neon 2s cubic-bezier(0.4, 0, 0.6, 1) infinite'
      },
      keyframes: {
        gradient: {
          '0%, 100%': {
            'background-size': '200% 200%',
            'background-position': 'left center'
          },
          '50%': {
            'background-size': '200% 200%',
            'background-position': 'right center'
          },
        },
        glow: {
          'from': {
            'text-shadow': '0 0 10px #00FF00, 0 0 20px #00FF00, 0 0 30px #00FF00'
          },
          'to': {
            'text-shadow': '0 0 20px #00FFFF, 0 0 30px #00FFFF, 0 0 40px #00FFFF'
          }
        },
        'pulse-neon': {
          '0%, 100%': {
            opacity: 1
          },
          '50%': {
            opacity: .5
          }
        }
      },
      boxShadow: {
        'neon': '0 0 5px #00FF00, 0 0 20px #00FF00, 0 0 30px #00FF00',
        'neon-blue': '0 0 5px #00FFFF, 0 0 20px #00FFFF, 0 0 30px #00FFFF'
      }
    },
  },
  plugins: [],
};